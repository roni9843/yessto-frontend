/** @type {import('next').NextConfig} */
const nextConfig = {
  // output: "export",
  images: {
    domains: [
      "picsum.photos",
      "api.lorem.space",
      "m.media-amazon.com",
      "i.ibb.co",
      "i.ibb.co.com",
      "tenor.com",
      "backend.aihomesd.com",
      "localhost:8000",
      "localhost",
      "aihomesd.com",
      "backend.aihomesd",
    ],
  },
};

export default nextConfig;
