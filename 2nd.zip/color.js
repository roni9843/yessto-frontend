// color.js
export const primaryColor = "#FF0000";

export const whiteColor = "#FFFFFF";

export const whiteColor_v_2 = "#F2F2F2"; // background

export const whiteColor_v_3 = "#D9D9D9";

export const grayColor = "#808080";

export const blackColor = "#010002";

export const redColor = "#FF0000";

// this is color

// this is test for git version control
