export default function BottomNavigationBar() {
  return <div>BottomNavigationBar</div>;
}
