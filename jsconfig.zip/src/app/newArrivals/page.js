"use client";

import NewArrivalsProducts from "./NewArrivalsProducts";

export default function page() {
  return (
    <div>
      <NewArrivalsProducts></NewArrivalsProducts>
    </div>
  );
}

//  <NewArrivalsProducts></NewArrivalsProducts>
