"use client";

import WeeklyOffers from "./WeeklyOffers";

export default function page() {
  return (
    <div>
      <WeeklyOffers></WeeklyOffers>
    </div>
  );
}

//  <NewArrivalsProducts></NewArrivalsProducts>
